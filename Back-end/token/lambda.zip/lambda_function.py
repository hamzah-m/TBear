import sys
import logging
import rds_config
import pymysql
import json
from random import randint

#rds settings
rds_host  = "tbtest.cq7mvqsp449u.us-east-1.rds.amazonaws.com"
name = "tbtest"
password = "tbtest123"
db_name = "tbtest"

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except Exception as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySql instance. " +str(e))
    sys.exit()

logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
def handler(event, context):
    x=randint(1000,9999)
    logger.info(x)
    with conn.cursor() as cur:
        cur.execute("insert into tokens (token) values "+x)
    