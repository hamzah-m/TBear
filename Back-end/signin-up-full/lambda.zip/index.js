var AWS=require("aws-sdk");
var AWSCognito=require("amazon-cognito-identity-js");
var cognitoUser;

exports.handler=function(event, context, callback){
  if(event.request.type=="forgotPassword"){
    resetPassword();
    callback(null, "success");
  }else if(event.request.type=="deleteUser"){
    deleteUser();
    callback(null, "success");
  }else
  if(event.request.type=="signUpDoctor"){
    
      signUpDoctor(event.request.email, event.request.password,event.request.firstName, event.request.lastName);
      if(cognitoUser!=null){
        console.log("success");
        callback(null, "success");
      }else{
        callback(null, "error");
        console.log("error outside");
      }
    
  }else if(event.request.type=="signIn"){
    try{    
      callback(null, signIn(event.request.email, event.request.password));
    }
    catch(err){
      console.log(err);
      callback(null, err);
    }
  }
  else if(event.request.type=="logout"){
    try{signOut();    callback(null,"success");
    }
    catch(err){
      console.log(err);
      callback(null, err);
    }
  }
  else
  if(event.request.type=="logoutGlobal"){
    try{signOutGlobal();     callback(null,"success");}
    catch(err){
      console.log(err);
      callback(null, err);
    }
  }else if(event.request.type=="signUpPatient"){
    try{
      signUpPatient(event.request.email, event.request.password,event.request.firstName, event.request.lastName);
      callback(null, "Success");
    }catch(UsernameExistsException){
      callback(null, "Username already exists");
      console.log("Username exists");  
    }
  }
}
function signUpPatient(email, password, firstName, lastName){
  var userPool=new AWSCognito.CognitoUserPool({
    UserPoolId: 'us-east-1_YvDUB1kkl',
    ClientId: '1cu4ftb10jv2n0924a5o6mbp21'
  });
  const attributeList = [];
  const attributeName = new AWSCognito.CognitoUserAttribute({
    Name: 'name',
    Value: firstName
  });
  const attributeFam= new AWSCognito.CognitoUserAttribute(
    {
      Name:'family_name',
      Value:lastName
    });
  const attributeEmail=new AWSCognito.CognitoUserAttribute(
    {
    Name: 'email',
    Value:email
    });
  attributeList.push(attributeName);
  attributeList.push(attributeFam);
  attributeList.push(attributeEmail);
  var ret=userPool.signUp(email, password,   attributeList, null, (err,result) => {
    userData = { 
      Username : 'username',
      Pool : userPool
    };
  if(err){
    console.log("error "+err.code);
  }
  callback("success");
  return "success";
   });
}
function deleteUser(){
  cognitoUser.deleteUser(function(err, result) {
    if (err) {
        alert(err);
        return;
    }
    console.log('call result: ' + result);
    return; 
});
}
function signUpDoctor(email, password, firstName, lastName) {
  var userPool=new AWSCognito.CognitoUserPool({
    UserPoolId: 'us-east-1_4siaepa4D',
    ClientId: '5gjkqckrgmc5r200cncj5oavgl'
  });
  const attributeList = [];
  const attributeName = new AWSCognito.CognitoUserAttribute({
    Name: 'name',
    Value: firstName
  });
  const attributeFam= new AWSCognito.CognitoUserAttribute(
    {
      Name:'family_name',
      Value:lastName
    });
  const attributeEmail=new AWSCognito.CognitoUserAttribute(
    {
    Name: 'email',
    Value:email
    });
  attributeList.push(attributeName);
  attributeList.push(attributeFam);
  attributeList.push(attributeEmail);
  var ret=userPool.signUp(email, password,   attributeList, null, (err,result) => {
    userData = { 
      Username : 'username',
      Pool : userPool
    };
  if(err){
    console.log("error "+err.code);
    return err.code;
    retu.ret=err.code;
  }
  callback("success");
  return "success";
   } );

  console.log("ret "+retu.ret);
  return retu.ret;
}


function signOut(){
  if (cognitoUser != null) {
    cognitoUser.signOut();
    console.log("signed out");
  }if(cognitoUser==null){
    console.log("sign in first to log out");
  }
}
function signOutGlobal(){
  cognitoUser.globalSignOut();
}

function signIn(email, password) {
  var userPool=new AWSCognito.CognitoUserPool({
    UserPoolId: 'us-east-1_4siaepa4D',
    ClientId: '5gjkqckrgmc5r200cncj5oavgl'
  });
    const authenticationDetails = new AWSCognito.AuthenticationDetails({
      Username: email,
      Password: password
    });
    cognitoUser = new AWSCognito.CognitoUser({
      Username: email,
      Pool: userPool
    });
    
    cognitoUser.authenticateUser(authenticationDetails, {
      onSuccess: (result) => {
        console.log('access token + ' + result.getAccessToken().getJwtToken());
        try {
          AsyncStorage.setItem('accessToken', JSON.stringify(result.getAccessToken()));
        } catch (error) {
          console.log('async error: '+error);
        }
      },
      onFailure: (err) => {
        console.log(err);
      },
      mfaRequired: (codeDeliveryDetails) => {
        console.log('mfaRequired'+codeDeliveryDetails);
      }
    });
}

function resetPassword(username) {
    cognitoUser.forgotPassword({
        onSuccess: function(result) {
            console.log('call result: ' + result);
        },
        onFailure: function(err) {
            alert(err);
        },
        inputVerificationCode() { // this is optional, and likely won't be implemented as in AWS's example (i.e, prompt to get info)
            var verificationCode = prompt('Please input verification code ', '');
            var newPassword = prompt('Enter new password ', '');
            cognitoUser.confirmPassword(verificationCode, newPassword, this);
        }
    });
}