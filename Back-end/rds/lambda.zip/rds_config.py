#config file containing credentials for rds mysql instance
db_username = "tbtest"
db_password = "tbtest123"
db_name = "tbtest" 